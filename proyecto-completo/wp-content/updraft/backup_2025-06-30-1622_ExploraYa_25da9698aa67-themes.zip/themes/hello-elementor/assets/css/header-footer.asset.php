<?php return array('dependencies' => array(), 'version' => '35eef2f211c36a776630');
